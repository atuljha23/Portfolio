A Pen created at CodePen.io. You can find this one at https://codepen.io/atuljha/pen/YdpKWw.

 pure css option with native radio and checkbox